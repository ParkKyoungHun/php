<?
$test = $_REQUEST["test1"];
echo ("test:".$test);
?>
<html>
<meta charset="utf-8">
nananananana
is
nananananan
<a href="http://naver.com">
<?echo ("test:".$test);?>
</a>
</html>
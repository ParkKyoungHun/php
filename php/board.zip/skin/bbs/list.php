<html>
<head>
<?
include "../../inc/config.inc.php";
include "config.inc.php";
$board=$_REQUEST["board"];
?>
<title><? echo $title_name ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
</head>
<? echo $board?>
<body bgcolor=<? echo $bgcolor ?>>

<?
if (!$offset) { $offset=0; }
$num_result=mysql_query("select id from $board where familly=0");
$num=mysql_num_rows($num_result);

$no = $num+1-$offset;
$today = date("Y-m-d");
$day = date("m/d");
?>

<center>
<form action=search.php?board=<? echo $board ?> method=post name=search>
<!-- �ٱ� �Դϴ� -->
<table border="0" width="88%" style="border-width:1px; border-color:<? echo $table_out ?>; border-style:solid;" cellpadding="0" cellspacing="0" width="964">
    <tr>
        <td width="846" bgcolor="<? echo $table_out ?>" height="19">
            <p><font size="2" face="����" color="white">&nbsp;&nbsp;total : <? echo $num ?>
            </font></p>
        </td>
        <td width="118" bgcolor="<? echo $table_out ?>" height="19">
            <p><font face="����ü" size="2" color="white">today : <? echo $day ?></font></p>
        </td>
    </tr>
    <tr>
        <td colspan="2" align=center>
<!-- ���� ���� -->
<br>
<table border=0 width=88%>
	<tr>
		<td align=center width=5% height=20 bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>no111</td>
		<td align=center width=61% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>subject</td>
		<td align=center width=10% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>name</td>
		<td align=center width=12% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>date</td>
		<td align=center width=7% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>hit</td>
	</tr>
</table>

<?
$result=mysql_query("select * from $board where familly=0 order by mother desc, sequence asc limit $offset,$limit");
while($row=mysql_fetch_array($result))
{

$wday=explode(" ",$row[wdate]);
$no = $no - 1;

$subject=htmlspecialchars($row[subject]);
$name=htmlspecialchars($row[name]);
$comment=htmlspecialchars($row[comment]);

echo "
<!--�۵��� ������ �ϴ� �κ�-->
<table border=0 width=88%>
	<tr onMouseOver=this.style.backgroundColor='gainsboro' onMouseOut=this.style.backgroundColor='' onclick=self.location.href='read.php?board=$board&id=$row[id]'>
		<td align=center width=5%><font size=2 face=���� color=$list_font>$no</td>
		<td width=61%>
";
	
	for ($a=0 ; $a < $row[step]  ; $a++	){
	echo "&nbsp;&nbsp;";
	}
	
	echo "<a href=read.php?board=$board&id=$row[id] title=\"$comment\"><font size=2 face=���� color=$list_font>$subject</a>";
	if ($row[familly_num] != 0)	{
	echo "&nbsp;<font size=1 color=gray>[$row[familly_num]]";
	}
	if ($wday[0] == $today ) 	{ echo "&nbsp;<img src=new.gif>	";	}	else	{	}

	echo "</td><td align=center width=10%><font size=2 face=���� color=$list_font>";

if (!$row[email])	{
		echo $name;
		}	else	{
		echo "<a href=mailto:$row[email]>$name</a>";
		}

echo "
		</td>
		<td align=center width=12%><font size=2 face=���� color=$list_font>$wday[0]</td>
		<td align=center width=7%><font size=2 face=���� color=$list_font>$row[see]</td>
	</tr>
</table>
";

}
$pages=intval($num/$limit) + 1 ;
// ������ ������ �ذ�
if ($num%$limit == 0)	{ $pages = $pages-1; }

mysql_close();

echo "
<table border=0>
	<tr>
		<td width=560 align=center><p><font size=2><a href=list.php?board=$board style=\"font-size : 8pt;\">[1]</a>
";

	for ($a=2;$a<$pages+1;$a++)	{
	
	$b = $b + $limit;
	
	echo "<a href=list.php?board=$board&offset=$b style=\"font-size : 8pt;\">[$a]</a>";	
	
	}
?>
		</p></td>
		<td width=130 align=right><font size=2 color=<? echo $list_font ?>></td>
	</tr>
</table>
<font color=<? echo $list_font ?> size=2 face=����>
<input type=radio name=point value=name>�̸�
<input type=radio name=point value=subject checked>����
<input type=radio name=point value=comment>����
<input type=text name=keyword class=box size=10 maxlength=15>
<input type=submit value=find class=submit>
<br>
</form>
<!-- ���� ���� -->
        </td>
    </tr>
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="21">
            <p align="left">
            <font size="1" face="����" color="white">&nbsp;
            <a href="http://tozigy.com" target="_blank" style="font-size:8pt;color:white;">copyright �� tozigy.com. All rights reserved.</a></font>
            </p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="21">
          <p align="left">
            <a href="write.php?board=<? echo $board ?>"><font size="2" face="����ü" color="white">write</a> | 
            <a href="list.php?board=<? echo $board ?>"><font size="2" face="����ü" color="white">list</a></font>
          </p>
        </td>
    </tr>
</table>
<!-- �ٱ� ���� -->
<script language="JavaScript">
	document.search.keyword.focus();
</script>
</body>
</html>

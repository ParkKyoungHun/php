<?
include "../../inc/config.inc.php";
$name = $_REQUEST["name"];
$comment = $_REQUEST["comment"];
$passwd = $_REQUEST["passwd"];
$subject = $_REQUEST["subject"];
$board = $_REQUEST["board"];
if ($name == '' || $comment == '' || $passwd == '' || $subject == '')	{
echo ("
<script>
	alert ('$name,$comment,$passwd,$subject : ������ �����ϼ���.');
	history.go(-1);
</script>
");
exit;
}

if ($row[upfile_type] ==	'image/gif'  or $row[upfile_type] == 'image/pjpeg' or $row[upfile_type] == 'image/bmp' or $row[upfile_type] == 'image/x-png' or $row[upfile_type] == '' )
{

$a = date("dms");
$upfile_name = $a.$upfile_name;

$result=mysql_query("select max(mother) from $board");
$row=mysql_fetch_array($result);
$row[0]=$row[0] + 1;

if ($upfile_size == 0) {
$upfile_name = '';
}

if ($html)	{
$html = 'yes';
} else {
$html = 'no';
}

$dbinsert = "insert into $board (name,email,homepage,passwd,subject,comment,html,upfile_name,upfile_type,upfile_size,wdate,ip,see,familly,familly_num,mother,step,sequence) ".
						"values ('$name','$email','$homepage','$passwd','$subject','$comment','$html','$upfile_name','$upfile_type','$upfile_size',now(),'$REMOTE_ADDR',0,0,0,$row[0],0,0)";
$result=mysql_query($dbinsert, $db);

if ($upfile_size > 0)	{
copy($upfile,"..//..//data//$upfile_name");
}	

}	else	{
echo ("
  <script>
  alert('���Ͼ��ε�� �׸����ϸ� �����մϴ�.')
  history.go(-1)
  </script>	");


}

mysql_close($db);

echo ("<meta http-equiv='Refresh' content='0; URL=list.php?board=$board'>");
?>

<?
// ������ �ҷ��´�.
include "../../inc/config.inc.php";
include "config.inc.php";
$day = date("m/d");
$board=$_REQUEST["board"];
?>
<html>
<head>
<title><? echo $title_name ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<style>
<!--
    td  { font-size : 9pt; text-decoration : none; font-family : ����;  }
    A:link  { font : 9pt;   color : <? echo $list_font?>;  text-decoration : none; font-family : ����; font-size : 9pt;  }
    A:visited  {   text-decoration : none; color : <? echo $list_font?>; font-size : 9pt;  }
    A:hover  {  text-decoration : underline; color : <? echo $list_font?>; font-size : 9pt;  }

.box {
Background-color:white; 
Border:1x SOLID gray
}
//-->
</style>
<SCRIPT LANGUAGE=JAVASCRIPT>
function Check()
{
passwd = document.del.passwd.value.length;
if ( passwd == 0 ) {
  alert("��ȣ�� �Է� �ϼ���.");
  document.del.passwd.focus();
  return;
}
del.submit();
}
</SCRIPT>
</head>

<body  bgcolor=<? echo $bgcolor ?>>
<center>
<?

// ��ȸ��($see) ������Ʈ 

$result0=mysql_query("select see from $board where id=$id");
$row0=mysql_fetch_array($result0);
$see=$row0[see]+1;
$sql=mysql_query("update $board set see=$see where id=$id");

$result=mysql_query("select * from $board where id=$id");
$row=mysql_fetch_array($result);

if ($row[html] == 'no' || $row[html] == '')	{
$comment=str_replace("<","&lt;",$row[comment]);
$comment=str_replace("<","&gt;",$comment);
$comment=str_replace("\n","<br>",$comment);
} else if ($row[html] == 'yes') {
$comment = eregi_replace ("<meta", "(������ �±�-->meta)", $row[comment]);
$comment = eregi_replace ("<script", "(������ �±�-->script)", $comment);
$comment = eregi_replace ("javascript", "(������ �±�-->java)", $comment);
$comment = eregi_replace ("alert", "(������ �±�-->alert)", $comment);
$comment = eregi_replace ("<pre", "(������ �±�-->pre)", $comment);
$comment = eregi_replace ("<xmp", "(������ �±�-->xmp)", $comment);
$comment = eregi_replace ("<input", "(������ �±�-->input)", $comment);
$comment=str_replace("\n","<br>",$comment);
}

$name=htmlspecialchars($row[name]);

$subject=htmlspecialchars($row[subject]);
$subject = str_replace("&nbsp;"," ",$subject);

$wdate = substr ("$row[wdate]",0,10);
?>
<!-- �ٱ� �Դϴ� -->
<table border="0" width="88%" style="border-width:1px; border-color:<? echo $table_out ?>; border-style:solid;" cellpadding="0" cellspacing="0" width="964">
    <tr>
        <td width="846" bgcolor="<? echo $table_out ?>" height="19">
            <p></p>
        </td>
        <td width="118" bgcolor="<? echo $table_out ?>" height="19">
            <p align=right><font face="����ü" size="2" color="white">today : <? echo $day ?></font>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td height="199" colspan="2" align=center>
<!-- ���� ���� -->
<br>
<table width=87% border=0 cellpadding=1 cellspacing=0>
<tr>
  <td width=563 height=20 align=center bgcolor=<?echo $table_in?>>
    <font color=<?echo $up_font?> size=2 face=����><b><?echo $subject ?></b></font>
	</td>
  <td bgcolor=<?echo $table_in?> align=right>
    <font color=<?echo $up_font?>>see:<?echo  $row[see] ?>&nbsp;</font>
	</td>
</tr>
<tr>
	<td width=717 height=20 colspan=2>
	<p><br>&nbsp;<font color=#272727>writen by 
<?
if ($row[email])	{
	echo "<a href=mailto:$row[email]><b>$name</b></a>&nbsp;";
} else {
	echo "<b>$name</b>";
}
?></p>
<? echo $comment?></p>
<p align=right><font color=dimgray>
date : <? echo $wdate ?><br>
ip : <? echo $row[ip] ?>
</p>
<p>
<?
if ($row[upfile_name])	{
	$tmp_file_name = substr ("$row[upfile_name]",6);
	echo ("<br>÷������ : <a href=../../data/$row[upfile_name]>$tmp_file_name</a>");
}

if ( $row[upfile_type] ==	'image/gif'  or $row[upfile_type] == 'image/pjpeg' or $row[upfile_type] == 'image/bmp' or $row[upfile_type] == 'image/x-png')	{
	echo "<br><img src=../../data/$row[upfile_name]> ";	
}
?>
</p>
	</font>
	</td>
</tr>
<tr>
	<td colspan=2>
<!-- ������ ������ -->
<table border=0 width=100%>
<?
$result=mysql_query("select id,name,comment,wdate from $board where familly=$id");
while($row_comment=mysql_fetch_array($result))
{
	$name=htmlspecialchars($row_comment[name]);
	$comment=htmlspecialchars($row_comment[comment]);
	$wdate = substr ("$row_comment[wdate]",0,10);
?>
	<tr onMouseOver=this.style.backgroundColor='gainsboro' onMouseOut=this.style.backgroundColor=''>
		<td width=15%><font size=2 face=����>[ <? echo $name ?> ]</td>
		<td width=73%><font size=2 face=����><? echo $comment ?></td>
		<td width=10% align=center><font size=2 face=���� color=dimgray><? echo $wdate ?></td>
		<td width=2% align=center><font size=2 face=���� color=dimgray><a href=del_comment_pre.php?board=<? echo $board ?>&id=<? echo $row_comment[id] ?>&main_id=<? echo $row[id] ?>>x</a></td>
	</tr>
<?
}
?>
	<tr>
		<td colspan=4 height=8></td>
	</tr>
<!-- ������ �ִ� �� -->
	<tr><form action=comment_insert.php?board=<? echo $board ?>&id=<? echo $id ?> method=post name=comment>
		<td align=right>
		<font size=2 color=dimgray face=����>Name : <input type=text name=name size=7 maxlength=10 class=box><br>
		<br>Pass : <input type=password name=passwd size=7 maxlength=10 class=box>
		</td>
		<td><textarea class=box cols=69 rows=4 name=comment></textarea></td>
		<td colspan=2 align=center>
		<input type=submit value=comment style="background-color:white; padding-top:21; padding-right:0; padding-bottom:21; padding-left:0; border-width:1; border-color:rgb(201,201,201); border-style:solid;">
		</td>
	</tr></form>
</table>
	</td>
</td>
<tr><form action=del.php?board=<? echo $board ?>&id=<?echo $row[id]?> method=post name=del onSubmit='return Check()'>
  <td align=left bgcolor=<?echo $table_in?>>
 		 <a href=list.php?board=<? echo $board ?>>&nbsp;<font color=white>list</a> |
 		 <a href=write.php?board=<? echo $board ?>><font color=white>write</a> |
 		 <a href=reply.php?board=<? echo $board ?>&id=<? echo $row[id] ?>&mother=<?echo $row[mother]?>&step=<?echo $row[step]?>&sequence=<?echo $row[sequence]?>><font color=white>reply</a> |
  	 <a href=edit.php?board=<? echo $board ?>&id=<?echo $id?>><font color=white>edit</a> |
  </td>
  <td align=right bgcolor=<?echo $table_in?>>
 	   <font color=white>&nbsp;Pw : &nbsp;<input type=password name=passwd size=8 class=box>
   	 <a href='javascript:Check();'><font color=white>[ Del ]</a>
  </td>
 </tr>
</table></form>
<!-- ���⼭ ���ʹ� list.php�� �����մϴ�. -->
<?
if (!$offset) { $offset=0; }
$num_result=mysql_query("select id from $board where familly=0");
$num=mysql_num_rows($num_result);

$no = $num+1-$offset;

?>
<center>
<table border=0 width=88%>
	<tr>
		<td colspan=5><font size=2 face=���� color=<? echo $list_font ?>>Total : <? echo $num ?></td>
	</tr>
	<tr>
		<td align=center width=5% height=20 bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>no</td>
		<td align=center width=61% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>subject</td>
		<td align=center width=10% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>name</td>
		<td align=center width=12% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>date</td>
		<td align=center width=7% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>hit</td>
	</tr>
</table>
<?
$result=mysql_query("select * from $board where familly=0 order by mother desc, sequence asc limit $offset,$limit");
while($row=mysql_fetch_array($result))
{
$no = $no - 1;
$wday=explode(" ",$row[wdate]);

$subject=htmlspecialchars($row[subject]);
$name=htmlspecialchars($row[name]);
?>
<!-- ������ ���� -->
<table border=0 width=88%>
	<tr onMouseOver=this.style.backgroundColor='gainsboro' onMouseOut=this.style.backgroundColor='' onclick=self.location.href='read.php?board=<? echo $board ?>&id=<? echo $row[id]?>'>
		<td align=center width=5%><font size=2 face=���� color=<? echo $list_font ?>>
		
<?
	if ( $id == $row[id] )	{
	echo "<b>$no</b>";
	} else	{
	echo $no;
	}

	echo "</td><td width=61%>";

	for ($a=0 ; $a < $row[step]  ; $a++	){
	echo "&nbsp;&nbsp;";
	}
	echo "<font size=2 face=���� color=$list_font>$subject</a>";
	
	if ($row[familly_num] != 0)	{
	echo "&nbsp;<font size=1 color=gray>[$row[familly_num]]";
	}
	
	$today = date("Y-m-d");
	if ($wday[0] == $today ) 	{ echo "&nbsp;<img src=new.gif>	";	}	else	{	}
	
	echo "</td><td align=center width=10%><font size=2 face=���� color=$list_font>";

if ($row[email])	{
		echo "<a href=mailto:$row[email]>$name</a>";
}	else {
		echo "$name";
}
?>
		</td>
		<td align=center width=12%><font size=2 face=���� color=<? echo $list_font ?>><? echo $wday[0] ?></td>
		<td align=center width=7%><font size=2 face=���� color=<? echo $list_font ?>><? echo $row[see] ?></td>
	</tr>
</table>
<?
}
$pages=intval($num/$limit) + 1;

mysql_close();
?>
<table width=88%>
	<tr>
		<td width=563 align=center><p><font size=2><a href=list.php?board=<? echo $board ?>>[1]</a>
		
<?
	for ($a=2;$a<$pages+1;$a++)	{
	
	$b = $b + $limit;
	echo "<a href=list.php?board=$board&offset=$b>[$a]</a>";	
	
	}
?>
		</p></td>
		<td width=130 align=right></td>
	</tr>
</table>
<!-- �˻� �κ� -->
<form action=search.php?board=<? echo $board ?> method=post name=search>
	<font color=<? echo $list_font ?> size=2 face=����>
	<input type=radio name=point value=name>�̸�
	<input type=radio name=point value=subject checked>����
	<input type=radio name=point value=comment>����
	<input type=text name=keyword class=box size=10 maxlength=15>
	<a href='javascript:document.search.submit();' onSubmit='return content_check(this)'>[ Find ]<br>
</form>
<!-- ���� ���� -->
        </td>
    </tr>
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="21">
            <p align="left">
            <font size="1" face="����" color="white">&nbsp;
            <a href="http://tozigy.com" target="_blank" style="font-size:8pt;color:white;">copyright �� tozigy.com. All rights reserved.</a></font>
            </p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="21">
         	<p align="right">
            <a href="write.php?board=<? echo $board ?>"><font size="2" face="����ü" color="white">write</a> | 
            <a href="list.php?board=<? echo $board ?>"><font size="2" face="����ü" color="white">list</a></font>&nbsp;
          </p>
        </td>
    </tr>
</table>
<!-- �ٱ� ���� -->
<P>
</center>
</body>
</html>

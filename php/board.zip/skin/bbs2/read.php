<?
// ������ �ҷ��´�.
include "../../inc/config.inc.php";
include "config.inc.php";
$day = date("m/d");
?>
<html>
<head>
<title><? echo $title_name ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<style>
<!--
    td  { font-size : 9pt; text-decoration : none; font-family : ����;  }
    A:link  { font : 9pt;   color : <? echo $list_font?>;  text-decoration : none; font-family : ����; font-size : 9pt;  }
    A:visited  {   text-decoration : none; color : <? echo $list_font?>; font-size : 9pt;  }
    A:hover  {  text-decoration : underline; color : <? echo $list_font?>; font-size : 9pt;  }

.box {
Background-color:white; 
Border:1x SOLID gray
}
//-->
</style>
<SCRIPT LANGUAGE=JAVASCRIPT>
function Check()
{
passwd = document.del.passwd.value.length;
if ( passwd == 0 ) {
  alert("��ȣ�� �Է� �ϼ���.");
  document.del.passwd.focus();
  return;
}
del.submit();
}
</SCRIPT>
</head>

<body  bgcolor=<? echo $bgcolor ?>>
<?
if ($id)	{
$result=mysql_query("select * from $board where id=$id");
$row=mysql_fetch_array($result);
}	else {
$result=mysql_query("select * from $board order by id desc limit 1");
$row=mysql_fetch_array($result);
}
// ��ȸ��($see) ������Ʈ
$result0=mysql_query("select see from $board where id=$row[id]");
$row0=mysql_fetch_array($result0);
$see=$row0[see]+1;
$sql=mysql_query("update $board set see=$see where id=$row[id]");


if ($row[html] == 'no' || $row[html] == '')	{
$comment=str_replace("<","&lt;",$row[comment]);
$comment=str_replace("<","&gt;",$comment);
$comment=str_replace("\n","<br>",$comment);
} else if ($row[html] == 'yes') {
$comment = eregi_replace ("<meta", "(������ �±�-->meta)", $row[comment]);
$comment = eregi_replace ("<script", "(������ �±�-->script)", $comment);
$comment = eregi_replace ("javascript", "(������ �±�-->java)", $comment);
$comment = eregi_replace ("alert", "(������ �±�-->alert)", $comment);
$comment = eregi_replace ("<pre", "(������ �±�-->pre)", $comment);
$comment = eregi_replace ("<xmp", "(������ �±�-->xmp)", $comment);
$comment = eregi_replace ("<input", "(������ �±�-->input)", $comment);
$comment=str_replace("\n","<br>",$comment);
}

$name=htmlspecialchars($row[name]);

$subject=htmlspecialchars($row[subject]);
$subject = str_replace("&nbsp;"," ",$subject);

$wdate = substr ("$row[wdate]",0,10);
?>
<!-- �ٱ� �Դϴ� -->
<table border="0" align=left width="98%" style="border-width:1px; border-color:<? echo $table_out ?>; border-style:solid;" cellpadding="0" cellspacing="0" width="964">
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="19">
            <p></p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="19">
            <p align=right><font face="����ü" size="2" color="white">today : <? echo $day ?></font>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td height="199" colspan="2" align=center>
<!-- ���� ���� -->
<br>
<table width=93% border=0 cellpadding=1 cellspacing=0>
<tr>
  <td colspan=2 width=50% height=20 bgcolor=<?echo $table_in?> align=center>
    <font color=<?echo $up_font?> size=2 face=����><b><?echo $subject ?></b></font>
	</td>
</tr>
<tr>
	<td width=500 height=20 colspan=2>
	<p><br>&nbsp;<font color=#272727>writen by 
<?
if ($row[email])	{
	echo "<a href=mailto:$row[email]><b>$name</b></a>&nbsp;";
} else {
	echo "<b>$name</b>";
}
?></p>
<? echo $comment?></p>
<p align=right><font color=dimgray>
date : <? echo $wdate ?><br>
ip : <? echo $row[ip] ?>
</p>
<p>
<?
if ($row[upfile_name])	{
	$tmp_file_name = substr ("$row[upfile_name]",6);
	echo ("<br>÷������ : <a href=../../data/$row[upfile_name]>$tmp_file_name</a>");
}

if ( $row[upfile_type] ==	'image/gif'  or $row[upfile_type] == 'image/pjpeg' or $row[upfile_type] == 'image/bmp' or $row[upfile_type] == 'image/x-png')	{
	echo "<br><img src=../../data/$row[upfile_name]> ";	
}
?>
</p>
	</font>
	</td>
</tr>
<tr>
	<td colspan=2>
<!-- ������ ������ -->
<table border=0 width=97% align=center>
<?
$result=mysql_query("select id,name,comment,wdate from $board where familly=$row[id]");
while($row_comment=mysql_fetch_array($result))
{
	$name=htmlspecialchars($row_comment[name]);
	$comment=htmlspecialchars($row_comment[comment]);
	$wdate = substr ("$row_comment[wdate]",5,5);
?>
	<tr onMouseOver=this.style.backgroundColor='gainsboro' onMouseOut=this.style.backgroundColor=''>
		<td width=1><font size=2 face=����>[ <? echo $name ?> ]</td>
		<td width=80%><font size=2 face=����><? echo $comment ?></td>
		<td width=50 align=center><font size=2 face=���� color=dimgray><? echo $wdate ?></td>
		<td width=10 align=right><font size=2 face=���� color=dimgray><a href=del_comment_pre.php?board=<? echo $board ?>&id=<? echo $row_comment[id] ?>&main_id=<? echo $row[id] ?>>x</a></td>
	</tr>
<?
}
?>
	<tr>
		<td colspan=4 height=8></td>
	</tr>
<!-- ������ �ִ� �� -->
	<tr><form action=comment_insert.php?board=<? echo $board ?>&id=<? echo $row[id] ?> method=post name=comment>
		<td align=left colspan=2>
		<font size=2 color=dimgray face=����>
		Name : <input type=text name=name size=7 maxlength=10 class=box>&nbsp;&nbsp;
		Pass : <input type=password name=passwd size=7 maxlength=10 class=box><br>
		<textarea class=box cols=47% rows=2 name=comment></textarea>
		</td>
		<td colspan=2 align=center><input type=submit value=comment style="background-color:white; padding-top:21; padding-right:0; padding-bottom:21; padding-left:0; border-width:1; border-color:rgb(201,201,201); border-style:solid;"></td>
	</tr></form>
</table><br>
	</td>
</td>
<tr><form action=del.php?board=<? echo $board ?>&id=<?echo $row[id]?> method=post name=del onSubmit='return Check()'>
  <td align=left bgcolor=<?echo $table_in?>>&nbsp;<font color=white>| 
 		 <a href=write.php?board=<? echo $board ?>><font color=white>write</a> |
 		 <a href=reply.php?board=<? echo $board ?>&id=<? echo $row[id] ?>&mother=<?echo $row[mother]?>&step=<?echo $row[step]?>&sequence=<?echo $row[sequence]?>><font color=white>reply</a> |
  	 <a href=edit.php?board=<? echo $board ?>&id=<?echo $row[id]?>><font color=white>edit</a> |
  </td>
  <td align=right bgcolor=<?echo $table_in?>>
 	   <font color=white size=2 face=����>&nbsp;Pw : &nbsp;<input type=password name=passwd size=8 class=box>
   	 <a href='javascript:Check();'><font color=white size=2 face=����>[ Del ]</a>
  </td>
 </tr>
</table></form>
<!-- ���� ���� -->
        </td>
    </tr>
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="21">
            <p align="left">
            <font size="1" face="����" color="white">&nbsp;
            copyright �� <a href="http://tozigy.com" target="_blank"><font size=1 color=white>
            tozigy.com</a>. All rights reserved.</a></font>
            </p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="21">
        </td>
    </tr>
</table>
<!-- �ٱ� ���� -->
<?
if ($id)	{
?>
<script language='javascript'>
	parent.frames.left.location.reload();
</script>
<?
}
?>
</body>
</html>

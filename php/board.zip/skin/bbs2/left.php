<html>
<head>
<?
include "../../inc/config.inc.php";
include "config.inc.php";
?>
<title><? echo $title_name ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
</head>

<body bgcolor=<? echo $bgcolor ?>>

<?
if (!$offset) { $offset=0; }
$num_result=mysql_query("select id from $board");
$num=mysql_num_rows($num_result);

$no = $num+1-$offset;
$today = date("Y-m-d");
$day = date("m/d");
?>
<form action=search.php?board=<? echo $board ?> method=post name=search>
<!-- �ٱ� �Դϴ� -->
<table border="0" width="95%" style="border-width:1px; border-color:<? echo $table_out ?>; border-style:solid;" cellpadding="0" cellspacing="0" width="964" align=right>
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="19">
            <p><font size="2" face="����" color="white">&nbsp;&nbsp;total : <? echo $num ?></font></p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="19" align=right>
            <p><font face="����ü" size="2" color="white">today : <? echo $day ?>&nbsp;</font></p>
        </td>
    </tr>
    <tr>
        <td colspan="2" align=center>
<!-- ���� ���� -->
<br>
<table border=0 width=95%>
	<tr>
		<td align=center width=5% height=20 bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>no</td>
		<td align=center width=61% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>subject</td>
		<td align=center width=16% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>name</td>
		<td align=center width=5% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>date</td>
		<td align=center width=7% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>hit</td>
	</tr>
<?
$result=mysql_query("select * from $board where familly=0 order by mother desc, sequence asc limit $offset,$limit");
while($row=mysql_fetch_array($result))
{

$wday=explode(" ",$row[wdate]);
$no = $no - 1;

// �� ���� �κ� ���� ����
$subject=htmlspecialchars($row[subject]);
$subject=stripslashes($subject); 
$subject_len=strlen($subject);
$cut_len=strlen(substr($subject,0,30));//���ڿ��� �ڸ� 
if($subject_len > $cut_len)	{//���� ���ڿ��� �ڸ� ���ڿ����� ������ �ڸ��� ���� 
for($a=0;$a < $cut_len;$a++)	{ 
$bite=ord(substr($subject, $a, 1)); 
if( $bite > 127 )	{//127���� ũ�� �ѱ۷� �����Ͽ� 2����Ʈ�� �ڸ� 
    $a++; 
} //if �� ����
}	//for �� ����
$subject=substr($subject,0,$a); 
} //if �� ����
if($subject_len > $cut_len)
$subject = $subject."...";
// ������ ���ڿ� ���� ���� ��

$name=htmlspecialchars($row[name]);

echo "
<!--�۵��� ������ �ϴ� �κ�-->
	<tr onMouseOver=this.style.backgroundColor='gainsboro' onMouseOut=this.style.backgroundColor='' onclick=parent.frames.right.location.href='read.php?board=$board&id=$row[id]'>
		<td align=center width=5%><font size=2 face=���� color=$list_font>$no</td>
		<td width=61%>
";
	
	for ($a=0 ; $a < $row[step]  ; $a++	){
	echo "&nbsp;&nbsp;";
	}
	
	echo "<font size=2 face=���� color=$list_font><a href=read.php?board=$board&id=$row[id] target=right>$subject</a>";
	if ($row[familly_num] != 0)	{
	echo "&nbsp;<font size=1 color=gray>[$row[familly_num]]";
	}
	if ($wday[0] == $today ) 	{ echo "&nbsp;<img src=new.gif>	";	}	else	{	}

	echo "</td><td align=center><font size=2 face=���� color=$list_font>";

if (!$row[email])	{
		echo $name;
		}	else	{
		echo "<a href=mailto:$row[email]>$name</a>";
		}

// ��¥ ����
$wdate = substr ($wday[0],5,5);
echo "
		</td>
		<td align=center width=12%><font size=2 face=���� color=$list_font>$wdate</td>
		<td align=center width=7%><font size=2 face=���� color=$list_font>$row[see]</td>
	</tr>
";
}
$pages=intval($num/$limit) + 1 ;
// ������ ������ �ذ�
if ($num%$limit == 0)	{ $pages = $pages-1; }
mysql_close();

echo "
</table>
<table border=0>
	<tr>
		<td width=560 align=center><p><font size=2><a href=left.php?board=$board style=\"font-size : 8pt;\">[1]</a>
";
	// �Ʒ��� ������ ǥ���ϴ� �κ�
	for ($a=2;$a<$pages+1;$a++)	{
	$b = $b + $limit;
	echo "<a href=left.php?board=$board&offset=$b style=\"font-size : 8pt;\">[$a]</a>";	
	}
?>
		</p></td>
		<td width=130 align=right><font size=2 color=<? echo $list_font ?>></td>
	</tr>
</table>
<font color=<? echo $list_font ?> size=2 face=����>
<input type=radio name=point value=name>�̸�
<input type=radio name=point value=subject checked>����
<input type=radio name=point value=comment>����
<input type=text name=keyword class=box size=10 maxlength=15>
<input type=submit value=find class=submit>
<br>
</form>
<!-- ���� ���� -->
        </td>
    </tr>
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="21">
            <p align="left">
            &nbsp;<font size="1" face="����" color="white">
            copyright �� <a href="http://tozigy.com" target="_blank"><font size=1 color=white>
            tozigy.com</a>. All rights reserved.</a></font>
            </p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="21" align=right>
          <a href="write.php?board=<? echo $board ?>" target=right><font size="2" face="����ü" color="white">write</a> | 
          <a href="left.php?board=<? echo $board ?>" target=_self><font size="2" face="����ü" color="white">list</a>&nbsp;</font>
        </td>
    </tr>
</table>
<!-- �ٱ� ���� -->
<script language="JavaScript">
	document.search.keyword.focus();
</script>
</body>
</html>

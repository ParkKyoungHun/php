<frameset cols="45%, 55%" border="1">
    <frame scrolling="auto" src=left.php?board=<? echo $board ?> name=left>
    <frame scrolling="auto" src=read.php?board=<? echo $board ?> name=right>
</frameset>

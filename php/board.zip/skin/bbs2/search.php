<?
include "../../inc/config.inc.php";
include "config.inc.php";
$day = date("m/d");
?>
<html><head>
<title><? echo $title_name ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
</head>
<body bgcolor=<? echo $bgcolor ?>>
<?
if ($keyword == '������� ¯�̾�!')	{
echo "
<script>
alert ('�����Դϴ�! ^o^V');
</script>
";
}

if ($keyword=="")	{	echo ("
  <script>
  alert('�˻�� �Է��ϼ���.')
  history.go(-1)
  </script>	");
}
 $dbsearch="select * from $board where $point like '%$keyword%' order by mother desc, sequence asc";
 $query=mysql_query($dbsearch,$db);
 $list=mysql_num_rows($query);
 $num=mysql_num_rows($query);
?>
<!-- �ٱ� �Դϴ� -->
<table border="0" align=right width="95%" style="border-width:1px; border-color:<? echo $table_out ?>; border-style:solid;" cellpadding="0" cellspacing="0" width="964">
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="19">
            <p><font size="2" face="����" color="white">&nbsp;&nbsp;Search : <? echo $num ?>
            </font></p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="19">
            <p align=right><font face="����ü" size="2" color="white">today : <? echo $day ?>&nbsp;&nbsp;</font></p>
        </td>
    </tr>
    <tr>
        <td colspan="2" align=center>
<!-- ���� ���� -->
<br>
<table border=0 width=95%>
	<tr>
		<td align=center width=5% height=20 bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>no</td>
		<td align=center width=61% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>subject</td>
		<td align=center width=10% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>name</td>
		<td align=center width=12% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>date</td>
		<td align=center width=7% bgcolor=<? echo $table_in ?>><font size=2 face=���� color=<? echo $up_font ?>>hit</td>
	</tr>
</table>
<?
	$num = $num +1;
	
if($list)
{
 while($row=mysql_fetch_array($query))
{
/* �˻��� �ش�� �κ��� �ٸ� ������ ó���մϴ�. */ 
  $subject=htmlspecialchars($row[subject]); 
  $subject=str_replace(" ","&nbsp; ",$subject);
  $subject=str_replace("$keyword","<font color=black face=���� size=2>$keyword</font>",$subject);
  $name=htmlspecialchars($row[name]); 
  $name=str_replace("$keyword","<font color=black face=���� size=2>$keyword</font>",$name);
  $day=explode(" ",$row[wdate]);

	$num = $num - 1;
?>

<table border=0 width=95%>
  <tr>
  	<td align=center width=5%><font size=2 face=���� color=<? echo $list_font ?>><? echo $num ?></td>
    <td width=61%>
    
<?
	for ($a=0 ; $a < $row[step]  ; $a++	){
	echo "&nbsp;&nbsp;";
	}
?>

    <a href=read.php?id=<? echo $row[id] ?>&board=<? echo $board ?> target=right><font color=<? echo $list_font ?>><? echo $subject ?></a></td>
    <td width=10% align=center>
<?
if (!$row[email])	{
		echo "<font color=$list_font face=����>$row[name]";
		}	else	{
		echo "<a href=mailto:$row[email]>$row[name]</a>";
		}
// ��¥ ����
$wdate = substr ($day[0],5,5);
?>  
    <td width=12% align=center><font color=<? echo $list_font?>><? echo $wdate ?></td>
    <td width=7% align=center><font color=<? echo $list_font ?>><? echo $row[see]?></td>
  </tr>
 </table>
<?
}
}else{
?>
<!-- �˻��� �Խù��� ���� �� -->
<font color=<? echo $list_font ?> size=2 face=����><a href="javascript:history.go(-1)">�˻��� �Խù��� �����ϴ�.</a></font>
<?
}
mysql_close($db);
?>
<form action=search.php?board=<? echo $board ?> method=post name=search>
<font color=<? echo $list_font ?> size=2 face=����>
<input type=radio name=point value=name>�̸�
<input type=radio name=point value=subject checked>����
<input type=radio name=point value=comment>����
<input type=text name=keyword class=box size=10 maxlength=15>
<input type=submit value=find class=submit>
<br><br>
<!-- ���� ���� -->
        </td>
    </tr>
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="21">
            <p align="left">
            <font size="1" face="����" color="white">&nbsp;
            copyright �� <a href="http://tozigy.com" target="_blank">
            <font size="1" face="����" color="white">tozigy.com</a>. All rights reserved.</a></font>
            </p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="21">
            <p align="right"><a href="write.php?board=<? echo $board ?>" target=right><font size="2" face="����ü" color="white">write</a> 
            | <a href="left.php?board=<? echo $board ?>"><font size="2" face="����ü" color="white">list</a></font>&nbsp;&nbsp;</p>
        </td>
    </tr>
</table>
<!-- �ٱ� ���� -->
</form>
<script>
	document.search.keyword.focus();
</script>
</body></html>

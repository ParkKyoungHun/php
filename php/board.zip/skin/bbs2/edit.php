<?
include "../../inc/config.inc.php";  //  �����ͺ��̽� ���� ���� ���� ����
include "config.inc.php";
$day = date("m/d");
?>
<html>
<head>
<title><? echo $title_name ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
<script language="javascript" src="write_check.js"></script>
</head>
<?
$result=mysql_query("select * from $board where id=$id");
$row=mysql_fetch_array($result);
$name=htmlspecialchars($row[name]);
?>

<body  bgcolor=<? echo $bgcolor ?>>
<form action=edit_ok.php?board=<? echo $board ?>&id=<? echo $id?>&name=<? echo $name ?> method=post name=tozzic onSubmit="return Write_Check(this)" enctype="multipart/form-data">     
<!-- �ٱ� �Դϴ� -->
<table border="0" align=left width="97%" style="border-width:1px; border-color:<? echo $table_out ?>; border-style:solid;" cellpadding="0" cellspacing="0" width="964">
    <tr>
        <td width="400" bgcolor="<? echo $table_out ?>" height="19">
            <p><font size="2" face="����" color="white">&nbsp;&nbsp;
            </font></p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="19">
            <p><font face="����ü" size="2" color="white">today : <? echo $day ?></font></p>
        </td>
    </tr>
    <tr>
        <td height="199" colspan="2" align=center>
<!-- ���� ���� -->
<br>
<table border=0 cellpadding=1 cellspacing=1>
	<tr>
		<td width=400 height=20 align=center bgcolor=<? echo $table_in ?>>
			<font color=<? echo $up_font ?>><B>�ۼ���</B></font>
		</td>
	</tr>
	<tr>
		<td height=20  bgcolor=<? echo $bgcolor?>>&nbsp;
<!-- �۾��� ���� ���� -->
<TABLE border=0 align=center>
	<TR>
		<TD width=60 height=20 align=left><font size=2 color=<? echo $list_font ?>>�̸�</TD>
		<TD width=300 height=20 align=left><font size=2 color=<? echo $list_font ?>><b><? echo $name ?></TD>
	</TR>
	<TR>
		<TD width=60 height=20 align=left><font size=2  color=<? echo $list_font ?>>�̸���</TD>
		<TD height=20 align=left><INPUT type=text name=email size=20 maxlength=25 class=box value="<? echo $row[email] ?>"></TD>
	</TR>
	<TR>
		<TD width=60 height=20 align=left bgcolor><font size=2  color=<? echo $list_font ?>>��й�ȣ</TD>
		<TD height=20 align=left bgcolor><INPUT type=password name=passwd size=8 maxlength=8 class=box><font color=<? echo $list_font ?>>(��й�ȣ�� ��ġ�ؾ� �մϴ�.)</TD>
	</TR>
	<TR>
		<TD width=60 height=20 align=left bgcolor><font size=2 color=<? echo $list_font ?>>�� ��</TD>
		<TD height=20 align=left bgcolor><INPUT type=text name=subject size=40 maxlength=45 class=box value="<? echo $row[subject] ?>">
		&nbsp;&nbsp;html<input type=checkbox name=html></TD>
	</TR>
	<TR>
		<TD width=60 height=20 align=left><font size=2  color=<? echo $list_font ?>>����</TD>
		<TD height=20 align=left>
<TEXTAREA name=comment cols=50% rows=15 class=box>
<? echo $row[comment] ?>
</TEXTAREA></TD>
	</TR>
	<tr>
		<td><font size=2  color=<? echo $list_font ?>>÷������</td><td><input type=file name=upfile size=30% maxlength=255 class=box>
			<br><font color=<? echo $list_font ?>>
<?
if ($row[upfile_name])	{
$tmp_file_name = substr ("$row[upfile_name]",6);
echo $tmp_file_name."�� ��ϵǾ� �ֽ��ϴ�. <input type=checkbox name=del_file>����";
}
?><br>���Ͼ��ε�� �׸����ϸ� �����մϴ�.
		</td>
	</tr>
	<TR>
		<TD align=center colspan=2><br>
			<input type=submit value=save class=submit>
			<input type=reset value=cancel class=submit>
			<input type=button value=back class=submit onclick='javascript:history.go(-1)'>
		</TD>
	</TR>
</TABLE>
<!-- �۾��� ���� ���� -->
		</td>       
	</tr>
</table><br>
<!-- ���� ���� -->
        </td>
    </tr>
    <tr>
        <td bgcolor="<? echo $table_out ?>" height="21">
            <p align="left">
            <font size="1" face="����" color="white">&nbsp;
            copyright �� <a href="http://tozigy.com" target="_blank"><font size=1 color=white>
            tozigy.com</a>. All rights reserved.</a></font>
            </p>
        </td>
        <td bgcolor="<? echo $table_out ?>" height="21">
            <p align="right"><a href="write.php?board=<? echo $board ?>"><font size="2" face="����ü" color="white">write</a>&nbsp;&nbsp;</font></p>
        </td>
    </tr>
</table>
<!-- �ٱ� ���� -->

</center>
<P>
<script>
document.tozzic.email.focus();
</script>
</body>
<?
mysql_close();
?>
</html>

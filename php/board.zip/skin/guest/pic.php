<p align=center>
<img src=img/<?=$pic?>.png onclick='javascript:self.close();' style="cursor:hand;">
</p>

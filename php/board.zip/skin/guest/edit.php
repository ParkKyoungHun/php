<html>

<head>
<title>ToziGuest ver 1.0</title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
<script language="javascript" src="writecheck.js"></script>
</head>
<?
include "../../inc/config.inc.php";
$result=mysql_query("select * from $board where id=$id");
$row=mysql_fetch_array($result)
?>
<body bgcolor="white">
<p>&nbsp;</p>
<p>&nbsp;</p>
<!-- �ٱ� ���̺� ���� -->
<table align="center" border="0" width="600" style="border-width:1px; border-color:rgb(181,20,16); border-style:solid;" cellpadding="0" cellspacing="0">
    <tr>
        <td bgcolor="#CC7777" height="22">
            <p><font color="white" size="2" face="����">&nbsp;</font><font size="2" face="����" color="white">�����ϱ�</font></p>
        </td>
    </tr>
    <tr>
        <td height="36">
<!-- �� �Է� �κ� -->
<p>&nbsp;</p>
<table border="0" width="539" align="center">
    <tr><form action=edit_ok.php?board=<? echo $board ?>&id=<? echo $id ?> onsubmit="return WriteCheck()" method=post name=tozzic>
        <td width="79">
            <p><font size="2" face="����" color="#B51410">Name</font></p>
        </td>
        <td width="157">
            <p><input type=text name=name class=box value="<? echo $row[name] ?>" maxlength="15" size="15"></p>
        </td>
        <td width="289">
            <p align="right"><font color="#B51410">�������� ���� �� �־��. 
            ��</font> </p>
        </td>
    </tr>
    <tr>
        <td width="79">
            <p><font size="2" face="����" color="#B51410">E-mail</font></p>
        </td>
        <td width="157">
            <p><input type=text name=email class=box value="<? echo $row[email] ?>" maxlength="30" size="20"></p>
        </td>
        <td width="289">
            <p align="right">&nbsp;
            <a href='javascript:addface("-.��^");'><img src="img/angry.gif" width="15" height="15" border="0"></a> 
            <a href='javascript:addface("��.��");'><img src="img/cry.gif" width="15" height="15" border="0"></a> 
            <a href='javascript:addface("-.��+");'><img src="img/kidding.gif" width="15" height="15" border="0"></a> 
            <a href='javascript:addface("��.��");'><img src="img/kiss.gif" width="15" height="15" border="0"></a> 
            <a href='javascript:addface("��.��");'><img src="img/sorrow.gif" width="15" height="15" border="0"></a> 
            <a href='javascript:addface("o.o");'><img src="img/surprise.gif" width="15" height="15" border="0"></a> 
            </p>
        </td>
    </tr>
    <tr>
        <td width="79">
            <p><font size="2" face="����" color="#B51410">HomePage</font></p>
        </td>
        <td width="157">
            <p><input type=text name=homepage class=box value="<? echo $row[homepage] ?>" maxlength="50" size="20"></p>
        </td>
        <td width="289">
            <p><font color="#B51410">&nbsp;Password &nbsp;&nbsp;<input type="password" name=passwd class=box maxlength="15" size="15"><br>(��ȣ�� ��ġ�ؾ� �մϴ�.)</font></p>
        </td>
    </tr>
    <tr>
        <td width="79">
            <p><font color="#B51410" size="2" face="����">Memo</font></p>
        </td>
        <td width="450" colspan="2">
            <p><textarea name=comment rows="7" cols="61" class=box><? echo $row[comment] ?></textarea></p>
        </td>
    </tr>
    <tr>
        <td width="79" height="11">
            <p><font size="2" face="����" color="#B51410">Image</font></p>
        </td>
        <td width="157" height="11">
            <p><select name="image" size="1" class=box>
                <option value="1">����</option>
                <option value="2">??</option>
                <option value="3">�޷���</option>
                <option value="4">�ĳ�</option>
                <option value="5">ahinaa</option>
								<option value="6">����</option>
								<option value="7">orphen</option>
								<option value="8">-_-*</option>
           			<option value="9">��ī¯</option>
            		<option value="10">������</option>
            		<option value="11">[k]ź��</option>
            		<option value="12">��������</option>
            		<option value="13">��ung��in</option>
            		<option value="14">��ü�����̡�</option>
            		<option value="15">��ung��in</option>
            		<option value="16">���̷�</option>
            		<option value="17">�ж�</option>
            		<option value="18">god����</option>
            		<option value="19">��</option>
            		<option value="20">Ű��</option>
            		<option value="21">BUBA</option>
            		<option value="22">��������</option>
            		<option value="23">By.Trippin</option>
            		<option value="24">����</option>
            		<option value="25">UB40</option>
            		<option value="26">������</option>
            		<option value="27">�ڱ����̡�</option>
            		<option value="28">��Ÿ</option>
            		<option value="29">koonja</option>
            		<option value="30">2121</option>
            		<option value="31">Looper</option>
            		<option value="32">ī�庴��</option>
            		<option value="33">�ʵ�����</option>
            		<option value="34">����</option>
                </select></p>
        </td>
        <td width="289" height="11">
            <p align="right"><font color="#B51410">&nbsp;
            <input type=submit value=save class=submit>
            <input type=reset value=cancel class=submit>
            <input type=button value=back class=submit onclick='history.go(-1)'>
            </font></p>
        </td>
    </tr></form>
</table>
<!-- �۾��� �� �� -->
<!-- �ٱ� ���̺� ���� -->
<p>&nbsp;</p>
			</td>
    </tr>
    <tr>
       <td bgcolor="#CC7777" height="21">
            <p align="right"><font size="2" face="����" color="white">&nbsp;Copyright 
            �� <a href="http://tozzic.net" target=_blank>Tozzic.net</a>. All right for Tozigy.</font></p>
       </td>
    </tr>
</table>
</body>
</html>

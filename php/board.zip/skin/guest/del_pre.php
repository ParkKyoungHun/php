<html>

<head>
<title>ToziGuest Ver 1.0</title>
<meta name="generator" content="Namo WebEditor v4.0">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
<SCRIPT LANGUAGE=JAVASCRIPT>
function WriteCheck()
{
passwd = document.tozzic.passwd.value.length;
if ( passwd == 0 ) {
  alert("��ȣ�� �Է� �ϼ���.");
  document.tozzic.passwd.focus();
  return false;
}
return true;
}
</script>
</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table align="center" border="0" width="304" style="border-width:1px; border-color:rgb(181,20,16); border-style:solid;" cellpadding="0" cellspacing="0">
    <tr><form action=del.php?board=<? echo $board ?>&id=<? echo $id ?> method=post name=tozzic onSubmit="return WriteCheck()">
        <td width="298" bgcolor="#CC7777" height="22">
            <p><font color="white" size="2" face="����">&nbsp;</font><font size="2" face="����" color="white">���� 
            ���� �մϴ�.</font></p>
        </td>
    </tr>
    <tr>
        <td width="298" height="36">
            <p align="center"><font size="2" face="����" color="#B51410">Password 
            :  <input type="password" name=passwd maxlength="15" size="10" class="box"> 
            &nbsp;<input type=submit value=Ȯ�� class=submit>&nbsp;<input type=button value=��� class=submit onclick='history.go(-1);'></font></p>
        </td>
    </tr>
    <tr>
        <td width="298" bgcolor="#CC7777" height="21">
            <p align="right"><font size="2" face="����" color="white">&nbsp;
            Copyright �� <a href=http://tozigy.com target=_blank>Tozigy.com</a>. All rights reserved.</font></p>
        </td>
    </tr></form>
</table>
<p>&nbsp;</p>
</body>
<script>
	document.tozzic.passwd.focus();
</script>
</html>

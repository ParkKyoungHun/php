<?
include "../../inc/config.inc.php";

$result=mysql_query("select passwd from $board where id=$id", $db);
$row=mysql_fetch_array($result);

 if (($passwd==$row[passwd]) || ($passwd==$admin_passwd))
 {

  $dbdel = "delete from $board where id=$id";
  $result=mysql_query($dbdel, $db);
  
  $dbdel = "delete from $board where familly=$id";
  $result=mysql_query($dbdel, $db);
	
 } else  {

 echo ("
  <script>
  alert('��й�ȣ�� Ʋ�Ƚ��ϴ�.')
  history.go(-1)
  </script>
  ");
  exit;

 }
mysql_close();
echo ("<meta http-equiv='Refresh' content='0; URL=list.php?board=$board'>");

?>

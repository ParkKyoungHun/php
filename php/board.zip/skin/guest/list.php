<html>
<head>
<title>ToziGuest ver 1.0</title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
<script language="javascript" src="writecheck.js"></script>
</head>

<body bgcolor="white">
<!-- �� �Է� �κ� -->
<table border="0" width="539" align="center">
    <tr><form action=insert.php?board=<? echo $board ?> method=post name=tozzic onSubmit="return WriteCheck()">
        <td width="79">
            <p><font size="2" face="����" color="#B51410">Name</font></p>
        </td>
        <td width="157">
            <p><input type=text name=name class=box maxlength="15" size="15"></p>
        </td>
        <td width="289">
            <p align="right"><font color="#B51410">�������� ���� �� �־��. 
            ��</font> </p>
        </td>
    </tr>
    <tr>
        <td width="79">
            <p><font size="2" face="����" color="#B51410">E-mail</font></p>
        </td>
        <td width="157">
            <p><input type=text name=email class=box maxlength="30" size="20"></p>
        </td>
        <td width="289">
            <p align="right">&nbsp;<img src="img/angry.gif" width="15" height="15" border="0" onclick='javascript:addface("-.��^");' style="cursor:hand"> 
            <img src="img/cry.gif" width="15" height="15" border="0" onclick='javascript:addface("��.��");' style="cursor:hand"> <img src="img/kidding.gif" width="15" height="15" border="0" onclick='javascript:addface("-.��+");' style="cursor:hand"> 
            <img src="img/kiss.gif" width="15" height="15" border="0" onclick='javascript:addface("��.��");' style="cursor:hand"> <img src="img/sorrow.gif" width="15" height="15" border="0" onclick='javascript:addface("��.��");' style="cursor:hand"> 
            <img src="img/surprise.gif" width="15" height="15" border="0" onclick='javascript:addface("o.o");' style="cursor:hand"> </p>
        </td>
    </tr>
    <tr>
        <td width="79">
            <p><font size="2" face="����" color="#B51410">HomePage</font></p>
        </td>
        <td width="157">
            <p><input type=text name=homepage class=box maxlength="50" size="20"></p>
        </td>
        <td width="289">
            <p><font color="#B51410">&nbsp;Password &nbsp;</font>&nbsp;<font color="#B51410"><input type="password" name=passwd class=box maxlength="15" size="15"></font></p>
        </td>
    </tr>
    <tr>
        <td width="79">
            <p><font color="#B51410" size="2" face="����">Memo</font></p>
        </td>
        <td width="450" colspan="2">
            <p><textarea name=comment rows="7" cols="61" class=box></textarea></p>
        </td>
    </tr>
    <tr>
        <td width="79" height="11">
            <p><font size="2" face="����" color="#B51410">Image</font></p>
        </td>
        <td width="157" height="11">
            <p><select name="image" size="1" class=box>
                <option value="1">����</option>
                <option value="2">??</option>
                <option value="3">�޷���</option>
                <option value="4">�ĳ�</option>
                <option value="5">ahinaa</option>
								<option value="6">����</option>
								<option value="7">orphen</option>
								<option value="8">-_-*</option>
           			<option value="9">��ī¯</option>
            		<option value="10">������</option>
            		<option value="11">[k]ź��</option>
            		<option value="12">��������</option>
            		<option value="13">��ung��in</option>
            		<option value="14">��ü�����̡�</option>
            		<option value="15">��ung��in</option>
            		<option value="16">���̷�</option>
            		<option value="17">�ж�</option>
            		<option value="18">god����</option>
            		<option value="19">��</option>
            		<option value="20">Ű��</option>
            		<option value="21">BUBA</option>
            		<option value="22">��������</option>
            		<option value="23">By.Trippin</option>
            		<option value="24">����</option>
            		<option value="25">UB40</option>
            		<option value="26">������</option>
            		<option value="27">�ڱ����̡�</option>
            		<option value="28">��Ÿ</option>
            		<option value="29">koonja</option>
            		<option value="30">2121</option>
            		<option value="31">Looper</option>
            		<option value="32">ī�庴��</option>
            		<option value="33">�ʵ�����</option>
            		<option value="34">����</option>
                </select></p>
        </td>
        <td width="289" height="11">
            <p align="right"><font color="#B51410">&nbsp;<input type=submit value=save class=submit> <input type=reset value=cancel class=submit>
            </font></p>
        </td>
    </tr></form>
</table>
<p align="center">&nbsp;</p>
<!-- �� ����Ʈ �κ� -->
<?
// start ������ ������ ������ ��Ͽ� ���� ���̴�.
if (!$start)	{
$start = 0;
}

include "../../inc/config.inc.php";
// ��� �Խù� ���� ���Ѵ�.
$num_result=mysql_query("select id from $board where familly=0");
$num=mysql_num_rows($num_result);

// �۵��� ������ �Ѵ�.
$result=mysql_query("select * from $board where familly=0 order by id desc limit $start,5");
while($row=mysql_fetch_array($result))
{
// Ư�� ���ڸ� ������ȭ ���ش�.
$comment = str_replace ("-.��^", "<img src=img/angry.gif>", $row[comment]);
$comment = str_replace ("��.��", "<img src=img/cry.gif>", $comment);
$comment = str_replace ("-.��+", "<img src=img/kidding.gif>", $comment);
$comment = str_replace ("��.��", "<img src=img/kiss.gif>", $comment);
$comment = str_replace ("��.��", "<img src=img/sorrow.gif>", $comment);
$comment = str_replace ("o.o", "<img src=img/surprise.gif>", $comment);

// ���� �ʴ� �±״� �ɷ�����.
$comment = eregi_replace ("<meta", "(������ �±�)", $comment);
$comment = eregi_replace ("<script", "(������ �±�)", $comment);
$comment = eregi_replace ("javascript", "(������ �±�)", $comment);
$comment = eregi_replace ("alert", "(������ �±�)", $comment);

$comment=str_replace("\n","<br>",$comment);
?>
<table border="0" align="center" width="533" style="border-width:1px; border-color:rgb(181,20,16); border-style:dotted;">
    <tr>
        <td width="104" height="10">
            <p><font size="2" face="����" color="#B51410">writen : 
           	<?
           	if ($row[email]) {
           	echo "<a href=mailto:$row[email]>";
           	}
           	?>
           	<? echo $row[name] ?></font></p>
        </td>
        <td width=55>
        	<?
        	if( $row[homepage] )	{
        	$homepage = str_replace ("http://", "", $row[homepage]);
        	echo "<font size=2 face=���� color=#B51410><a href=http://$homepage target=_blank>hompy</a>";
        	}
        	?>
        </td>
        <td width="364" height="10">
            <p align="right"><font size="2" face="����" color="#B51410">
            when : <? echo $row[wdate] ?> 
            <a href=edit.php?board=<? echo $board ?>&id=<? echo $row[id] ?>>[edit]</a> 
            <a href=del_pre.php?board=<? echo $board ?>&id=<? echo $row[id] ?>>[del]</a> 
            <a href=reply.php?board=<? echo $board ?>&id=<? echo $row[id] ?>>[reply]</a> 
            </font></p>
        </td>
    </tr>
    <tr>
        <td height=82>
            <p align="left"><img src="img/<? echo $row[upfile_name] ?>.png" width="100" height="100" border="0" style="cursor:hand;" onClick="window.open('pic.php?pic=<?=$row[upfile_name] ?>','_blank','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=400 top=100 left=300')"></p>
        </td>
        <td height=82 colspan=2>
            <p align="left"><font color="#333333"><? echo $comment ?></font></p>
        </td>
    </tr>
    <tr>
        <td>
            <p>&nbsp;</p>
        </td>
        <td colspan=2>
        <!-- ����� ǥ���ϴ� �κ� -->
        <?
        $result2=mysql_query("select * from $board where familly=$row[id]");
				while($row2=mysql_fetch_array($result2))
				{
					// Ư�� ���ڸ� ���������� �ٲپ� �ش�.
					$comment = str_replace ("-.��^", "<img src=img/angry.gif>", $row2[comment]);
					$comment = str_replace ("��.��", "<img src=img/cry.gif>", $comment);
					$comment = str_replace ("-.��+", "<img src=img/kidding.gif>", $comment);
					$comment = str_replace ("��.��", "<img src=img/kiss.gif>", $comment);
					$comment = str_replace ("��.��", "<img src=img/sorrow.gif>", $comment);
					$comment = str_replace ("o.o", "<img src=img/surprise.gif>", $comment);
					
					$comment=str_replace("\n","<br>",$comment);
					
					// ���� ���� html �±׸� �ɷ�����.
					$comment = eregi_replace ("<meta", "(������ �±�)", $comment);
					$comment = eregi_replace ("<script", "(������ �±�)", $comment);
					$comment = eregi_replace ("javascript", "(������ �±�)", $comment);
					$comment = eregi_replace ("alert", "(������ �±�)", $comment);	
				?>
            <table border="0" width="400" cellpadding="0" cellspacing="0" align="center">
              <tr><form action=insert.php method=post name=tozigy>
                <td width="286" height="122" bgcolor="#EEE6E6" rowspan="2">
                  <p><font color="#B51410">&nbsp;&nbsp;reply : 
           	<?
           	if ($row2[email]) {
           	echo "<a href=mailto:$row2[email]>";
           	}
           	echo "$row2[name]</a> , ";
           	if ($row2[homepage]) {
           	$homepage = str_replace ("http://", "", $row2[homepage]);
           	echo "<a href=http://$homepage target=_blank>hompy</a> ,";
           	}
           	?>
                  
                  when : <? echo $row2[wdate] ?></font></p>
                  <p><font color="#333333">&nbsp;<? echo $comment ?></font></p>
                </td>
                <td width="104" bgcolor="#EEE6E6" height="102">
                  <p align="right"><img src="img/<? echo $row2[upfile_name] ?>.png" width="100" height="100" border="0" style="cursor:hand;" onClick="window.open('pic.php?pic=<?=$row2[upfile_name] ?>','_blank','toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=400,height=400 top=100 left=300')"></p>
                </td>
              </tr>
              <tr>
                <td width="104" bgcolor="#EEE6E6" height="20">
                  <p align="right"><font color="#B51410">
                  <a href=edit.php?board=<? echo $board ?>&id=<? echo $row2[id] ?>>[edit]</a> 
                  <a href=del_pre.php?board=<? echo $board ?>&id=<? echo $row2[id] ?>>[del]</a>&nbsp;</font></p>
                </td>
              </tr></form>
            </table><br>
        <?
        }
        ?>
        <!-- ����� ���� -->
        </td>
    </tr>
</table><br>
<?
}
// ����¡ �κ�
echo "<center>";
$start=0;
$page = intval($num / 5) +1;
for ($a=1;$a < $page+1;$a++)	{
echo "<a href=list.php?board=$board&start=$start><font size=2 face=���� color=#B51410>[$a]</font></a>";
$start=$start + 5;
}
?>
<p><font size=2 face=���� color=#B51410>Copyright �� <a href=http://tozigy.com target=_blank>Tozigy.com</a>. All rights reserved.</p>
<!-- �� ������ ���� -->
</body>

</html>

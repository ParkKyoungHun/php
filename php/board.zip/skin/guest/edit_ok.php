<?
include "../../inc/config.inc.php";

$result=mysql_query("select passwd from $board where id=$id", $db);
$row=mysql_fetch_array($result);

 	if (($passwd==$row[passwd]) || ($passwd==$admin_passwd))
 	{
	$dbup = "update $board set upfile_name=$image,comment='$comment',name='$name',homepage='$homepage',email='$email' where id=$id";
	$result=mysql_query($dbup, $db);

	}	else	{
	echo ("
  <script>
  alert('��й�ȣ�� Ʋ�Ƚ��ϴ�.')
  history.go(-1)
  </script>
  ");
  exit;
 	}
 	
mysql_close($db);

echo ("<meta http-equiv='Refresh' content='0; URL=list.php?board=$board'>");
?>

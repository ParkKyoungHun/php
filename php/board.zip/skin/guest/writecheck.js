<!--
function addface(article){
	document.forms[0].comment.value=document.forms[0].comment.value+article;
}
function WriteCheck()
{
name = document.tozzic.name.value.length;
passwd = document.tozzic.passwd.value.length;
comment = document.tozzic.comment.value.length;
if ( name == 0 ) {
  alert("�̸��� �Է� �ϼ���.");
  document.tozzic.name.focus();
  return false;
}
if ( passwd == 0 ) {
  alert("��ȣ�� �Է� �ϼ���.");
  document.tozzic.passwd.focus();
  return false;
}
if ( comment == 0 ) {
  alert("���� �Է� �ϼ���.");
  document.tozzic.comment.focus();
  return false;
}

return true;
}
//-->

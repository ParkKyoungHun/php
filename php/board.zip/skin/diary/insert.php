<?
include "../../inc/config.inc.php";


if (!$familly)
{
	if ($passwd != $admin_passwd)	{
		echo "
		<script>
			alert ('��й�ȣ�� Ʋ�Ƚ��ϴ�.');
			history.go(-1);
		</script>
		";
		exit;
	}
}

if ($upfile_type ==	'image/gif'  || $upfile_type == 'image/pjpeg' || $upfile_type == 'image/bmp' || $upfile_type == 'image/x-png' || $upfile_size == 0)
{

$a = date("dms");
$upfile_name = $a.$upfile_name;

if ($upfile_size == 0) {
$upfile_name = '';
}

if (!$id)	{
$id = 0;
}

$dbinsert = "insert into $board (name,subject,comment,upfile_name,passwd,wdate,familly,familly_num,ip,see) values ".
						"('$name','$subject','$comment','$upfile_name','$passwd',now(),$id,0,'$REMOTE_ADDR',0)";
$result=mysql_query($dbinsert, $db);

if ($upfile_size > 0)	{
copy($upfile,"..//..//data//$upfile_name");
}	

}	else	{
echo ("
  <script>
  alert('���Ͼ��ε�� �׸����ϸ� �����մϴ�.')
  history.go(-1)
  </script>	");
exit;

}

mysql_close($db);

echo ("<meta http-equiv='Refresh' content='0; URL=list.php?board=$board&id=$id'>");

?>

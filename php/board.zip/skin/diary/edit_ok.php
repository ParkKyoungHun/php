<?
include "../../inc/config.inc.php";

if ($upfile_type ==	'image/gif' || $upfile_type == 'image/pjpeg' || $upfile_type == 'image/bmp' || $upfile_type == 'image/x-png' || $upfile_size == 0 )
{

$result=mysql_query("select passwd,upfile_name from $board where id=$id", $db);
$row=mysql_fetch_array($result);

 	if (($passwd==$row[passwd]) || ($passwd==$admin_passwd))
 	{

	$dbup = "update $board set subject='$subject',comment='$comment' where id=$id";
	$result=mysql_query($dbup, $db);

			if ($del_file)	{
			unlink("..//..//data//$row[upfile_name]");
			$dbup = "update $board set upfile_name='' where id=$id";
			$result=mysql_query($dbup, $db);
			}
			
			if ($upfile_size > 0)	{
			$a = date("dms");
			$upfile_name = $a.$upfile_name;
			$dbup = "update $board set upfile_name='$upfile_name' where id=$id";
			$result=mysql_query($dbup, $db);
			copy($upfile,"..//..//data//$upfile_name");
			}
	
	}	else	{
	echo ("
  <script>
  alert('��й�ȣ�� Ʋ�Ƚ��ϴ�.')
  history.go(-1)
  </script>
  ");
  exit;
 	}
 
}	else	{
echo ("
  <script>
  alert('���Ͼ��ε�� �׸����ϸ� �����մϴ�.')
  history.go(-1)
  </script>	");
	exit;
}
	
mysql_close($db);

echo ("<meta http-equiv='Refresh' content='0; URL=list.php?board=$board&id=$id'>");
?>

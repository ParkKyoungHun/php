<html>

<head>
<title>Tozigy diary Ver 1.1</title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
<script>
<!--
function WriteCheck()
{
passwd = document.tozzic.passwd.value.length;
comment = document.tozzic.comment.value.length;
name = document.tozzic.name.value.length;
if ( name == 0 ) {
  alert("�̸��� �Է� �ϼ���.");
  document.tozzic.name.focus();
  return false;
}
if ( passwd == 0 ) {
  alert("��ȣ�� �Է� �ϼ���.");
  document.tozzic.passwd.focus();
  return false;
}
if ( comment == 0 ) {
  alert("������ �Է��ϼ���.");
  document.tozzic.comment.focus();
  return false;
}
return true;
}
-->
</script>
</head>
<?
include "../../inc/config.inc.php";

$num_result=mysql_query("select id from $board");
$num=mysql_num_rows($num_result);

if ($id)	{
$tozigy = 'where id ='. $id;
}	else {
$tozigy = 'where familly=0 order by id desc limit 1';
}

$result=mysql_query("select id,subject,upfile_name,comment from $board $tozigy");
$row=mysql_fetch_array($result);

$comment=htmlspecialchars($row[comment]);
$comment=str_replace("\n","<br>",$comment);
$comment=str_replace(" ","&nbsp;",$comment);

$when = substr ($row[wdate],0,10);
$wdate = urlencode ($row[wdate]);
?>
<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red" topmargin="0" marginheight="0">
<table border="0" width="75%" align="center" cellpadding="0" cellspacing="0">
    <tr>
        <td width="25">
            <p><img src="img/line_1.gif" width="25" height="43" border="0"></p>
        </td>
        <td width="50%" background="img/line_2.gif" colspan="2">
            <p>&nbsp;</p>
        </td>
        <td width="35">
            <p><img src="img/line_3.gif" width="30" height="43" border="0"></p>
        </td>
    </tr>
    <tr>
        <td style="border-top-width:0; border-right-width:0; border-bottom-width:1px; border-left-width:1px; border-color:rgb(181,20,16); border-bottom-style:solid; border-left-style:solid;" rowspan="6">
            <p>&nbsp;</p>
        </td>
        <td width="30%">
            <p><font size="2" face="����" color="#B51410"><br>&nbsp;subject : <? echo $row[subject] ?></p>
        </td>
        <td width="70%">
            <p align=right><font size="2" face="����" color="#B51410"><br>&nbsp;when : <? echo $when ?> <a href="del_pre.php?board=<? echo $board ?>&id=<? echo $row[id] ?>">[del]</a><a href="edit.php?board=<? echo $board ?>&id=<? echo $row[id] ?>">[edit]</a></font></p>
        </td>
        <td background="img/line_4.gif" rowspan="5">
            <p>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td colspan=2 align=center><br>
        	<?
        	if ($row[upfile_name])
        	{
        		echo "
            <p align=center><img src=\"../../data/$row[upfile_name]\" border=0></p>
            ";
          }
          ?><br><? echo $comment ?><br><br>
        </td>
    </tr>
    <tr>
        <td colspan="2">
        	<?
     			$result=mysql_query("select id,name,comment,wdate from $board where familly='$row[id]'");
					while($row2=mysql_fetch_array($result))
					{
					$row2[wdate] = substr ($row2[wdate],0,10);
					?>
            <table border="0" align="center" width="90%" cellpadding="0" cellspacing="0">
                <tr>
                    <td width="15%" style="border-top-width:0px; border-bottom-width:1px; border-top-color:rgb(204,119,119); border-bottom-color:rgb(204,119,119); border-top-style:solid; border-bottom-style:solid;">
                        <p><font size="2" face="����" color="gray">&nbsp;<? echo $row2[name] ?></font></p>
                    </td>
                    <td width="70%" style="border-top-width:0px; border-bottom-width:1px; border-top-color:rgb(204,119,119); border-bottom-color:rgb(204,119,119); border-top-style:solid; border-bottom-style:solid;">
                        <p><font size="2" face="����" color="gray"><? echo $row2[comment] ?></font></p>
                    </td>
                    <td align=center width="18%" style="border-top-width:0px; border-bottom-width:1px; border-top-color:rgb(204,119,119); border-bottom-color:rgb(204,119,119); border-top-style:solid; border-bottom-style:solid;">
                        <p><font size="2" face="����" color="#B51410"><? echo $row2[wdate] ?></font></p>
                    </td>
                    <td align=center width="7%" style="border-top-width:0px; border-bottom-width:1px; border-top-color:rgb(204,119,119); border-bottom-color:rgb(204,119,119); border-top-style:solid; border-bottom-style:solid;">
                        <p><a href="del_pre.php?board=<? echo $board ?>&id=<? echo $row2[id] ?>"><font size="2" face="����" color="#B51410">x</a>&nbsp;</font></p>
                    </td>
                </tr>
            </table><br>
          <?
          }
          ?>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <div align="right"><form action=insert.php?board=<? echo $board ?>&id=<? echo $row[id] ?> name=tozzic method=post onSubmit="return WriteCheck()">
                <table border="0" width="578">
                    <tr>
                        <td width="41">
                            <p><font size="2" face="����" color="#9C0804">Name:</font></p>
                        </td>
                        <td width="84">
                            <p><input type=text name=name maxlength="10" size="10" class=box></p>
                        </td>
                        <td width="393" rowspan="2"><textarea rows="3" cols="53" name=comment onfocus="document.tozzic.comment.value=''" class=box>--������ �޾� �ּ���--</textarea></td>
                        <td width="42" rowspan="2">
                            <p align="center"><input type=image src="img/write.gif" width="30" height="46" border="0"></a></p>
                        </td>
                    </tr>
                    <tr>
                        <td width="41">
                            <p><font size="2" face="����" color="#9C0804">Pass 
                            :</font></p>
                        </td>
                        <td width="84">
                            <p><input type="password" name=passwd maxlength="10" size="10" class=box></p>
                        </td>
                    </tr>
                </table>
            </div></form>
        </td>
    </tr>
    <tr>
        <td height="32">
            <p align="left"><a href=write.php?board=<? echo $board ?>><img src="img/write_2.gif" width="50" height="22" border="0"></a></p>
        </td>
        <td height="32">
            <p align="right"><font color="#9C0804" size="2" face="����">
          <?
          if ($start>10)	{
          $pre = $start-10;
          echo "<a href=list.php?board=$board&id=$id&start=$pre>��</a> ";
          }
          if (!$start)	{
          $start = 1;
          }
          $a=$start-1;
          $result=mysql_query("select id from $board where familly=0 order by id desc limit $a,10");
					while($row=mysql_fetch_array($result))
					{
          $a=$a+1;
          echo "<a href=list.php?board=$board&id=$row[id]&start=$start>[$a]</a>";
          }
          $next = $start+10;
          if ($num > $next)	{
       		echo "&nbsp;<a href=list.php?board=$board&id=$id&start=$next>��</a></font></p>";
       		}
       		?>
        </td>
    </tr>
    <tr>
        <td style="border-bottom-width:1px; border-bottom-color:rgb(181,20,16); border-bottom-style:solid;">
            <p>&nbsp;</p>
        </td>
        <td style="border-bottom-width:1px; border-bottom-color:rgb(181,20,16); border-bottom-style:solid;">
            <p>&nbsp;</p>
        </td>
        <td height="19">
            <p><img src="img/line_5.gif" width="30" height="19" border="0"></p>
        </td>
    </tr>
</table>
<p>&nbsp;<font size="2" face="����">copyright �� <a href=http://tozigy.com target=_blank>Tozigy.com</a>. All rights reserved. 
programming by <a href="http://tozigy.com/" target=_blank>Tozigy</a>. skin by <a href="http://chouette.pe.kr" target=_blank>miniMaru</a>.</p>
<br>
</body>
</html>

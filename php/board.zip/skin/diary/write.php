<html>

<head>
<title>Tozigy diary Ver 1.1</title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<link rel="STYLESHEET" type="text/css" href="toziboard.css">
<script language="javascript" src="writecheck.js"></script>
</head>

<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red">
<p>&nbsp;</p><form action=insert.php?board=<? echo $board ?> onSubmit="return WriteCheck()" method=post name=tozzic enctype="multipart/form-data">
<table align="center" border="0" cellpadding="0" cellspacing="0" width="663">
    <tr>
        <td width="23">
            <p><img src="img/line_1.gif" width="25" height="43" border="0"></p>
        </td>
        <td width="610" background="img/line_2.gif">
            <p>&nbsp;</p>
        </td>
        <td width="30">
            <p><img src="img/line_3.gif" width="30" height="43" border="0"></p>
        </td>
    </tr>
    <tr>
        <td width="22" height="264" style="border-top-width:0; border-right-width:0; border-bottom-width:0; border-left-width:1px; border-color:rgb(181,20,16); border-top-style:none; border-right-style:none; border-bottom-style:none; border-left-style:solid;">
            <p>&nbsp;</p>
        </td>
        <td width="610" height="264">
            <table border="0" width="544" align="center">
                <tr>
                    <td width="80">
                        <p align="right"><font size="2" face="����" color="#B51410">Passwd 
                        </font></p>
                    </td>
                    <td width="454">
                        <p><input type=password name=passwd maxlength="15" size="15" class=box> <font size="2" face="����" color="#B51410">(������ ��ȣ�� ��ġ�ؾ� �մϴ�.)</p>
                    </td>
                </tr>
                <tr>
                    <td width="80">
                        <p align="right"><font size="2" face="����" color="#B51410">Subject 
                        </font></p>
                    </td>
                    <td width="454">
                        <p><input type=text name=subject maxlength="50" size="40" class=box></p>
                    </td>
                </tr>
                <tr>
                    <td width="80">
                        <p align="right"><font size="2" face="����" color="#B51410">Comment 
                        </font></p>
                    </td>
                    <td width="454">
                        <p><textarea rows="5" cols="60" name=comment class=box></textarea></p>
                    </td>
                </tr>
                <tr>
                    <td width="80">
                        <p align="right"><font size="2" face="����" color="#B51410">Picture 
                        </font></p>
                    </td>
                    <td width="454">
                        <p><input type=file name=upfile class=box maxlength="80" size="40"></p>
                    </td>
                </tr>
                <tr>
                    <td width="538" colspan="2">
                        <p align="center"><font color="#B51410" size="2" face="����">&nbsp;</font></p>
                    </td>
                </tr>
                <tr>
                    <td width="538" colspan="2">
                        <p align="center"><font color="#B51410" size="2" face="����">
                        <input type=submit value=save class=submit> 
                        <input type=reset value=cancel class=submit>
                        <input type=button value=back class=submit onclick='history.go(-1)'></font></p>
                    </td>
                </tr>
            </table>
        </td>
        <td width="30" height="264" background="img/line_4.gif">
            <p>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td width="22" style="border-top-width:0; border-right-width:0; border-bottom-width:1px; border-left-width:1px; border-bottom-color:rgb(181,20,16); border-left-color:rgb(181,20,16); border-top-style:none; border-right-style:none; border-bottom-style:solid; border-left-style:solid;">
            <p>&nbsp;</p>
        </td>
        <td width="610" style="border-bottom-width:1px; border-bottom-color:rgb(181,20,16); border-bottom-style:solid;">
            <p><font size="2" face="����" color="#B51410">Copyright �� <a href=http://tozigy.com target=_blank>Tozigy.com</a>. All rights reserved.</p>
        </td>
        <td width="30">
            <p><img src="img/line_5.gif" width="30" height="19" border="0"></p>
        </td>
    </tr>
</table></form>
<p>&nbsp;</p>
</body>
<script>
	document.tozzic.passwd.focus();
</script>

</html>

<html>

<head>
<title>Tozigy diary Ver 1.0</title>
<meta http-equiv="Content-Type" content="text/html; charset=EUC-KR">
<style>
<!--
    td  { font-size : 9pt;   }
    A:link  { font : 9pt;   color : #B51410 ;  text-decoration : none; font-family : ����; font-size : 9pt;  }
    A:visited  {   text-decoration : none; color : #B51410 ; font-size : 9pt;  }
    A:hover  {  text-decoration : underline; color : #B51410 ; font-size : 9pt;  }

.box {
Background-color: #F6EBEB; 
Border:1x SOLID #B51410
}
//-->
</style>
<SCRIPT LANGUAGE=JAVASCRIPT>
function WriteCheck()
{
passwd = document.tozzic.passwd.value.length;
comment = document.tozzic.comment.value.length;
subject = document.tozzic.subject.value.length;

if ( passwd == 0 ) {
  alert("��ȣ�� �Է� �ϼ���.");
  document.tozzic.passwd.focus();
  return;
}
if ( subject == 0 ) {
  alert("������ �Է��ϼ���.");
  document.tozzic.subject.focus();
  return;
}
if ( subject > 35 ) {
  alert("������ �ʹ� ��ϴ�.");
  document.tozzic.subject.focus();
  return;
}
if ( comment == 0 ) {
  alert("������ �Է��ϼ���.");
  document.tozzic.comment.focus();
  return;
}

tozzic.submit();
}
</script>
</head>
<?
include "../../inc/config.inc";
$result=mysql_query("select * from $board where id=$id");
$row=mysql_fetch_array($result)
?>
<body bgcolor="white" text="black" link="blue" vlink="purple" alink="red">
<p>&nbsp;</p><form action=edit_ok.php?board=<? echo $board ?>&id=<? echo $id ?> method=post name=tozzic enctype="multipart/form-data">
<table align="center" border="0" cellpadding="0" cellspacing="0" width="663">
    <tr>
        <td width="23">
            <p><img src="img/line_1.gif" width="25" height="43" border="0"></p>
        </td>
        <td width="610" background="img/line_2.gif">
            <p>&nbsp;</p>
        </td>
        <td width="30">
            <p><img src="img/line_3.gif" width="30" height="43" border="0"></p>
        </td>
    </tr>
    <tr>
        <td width="22" height="264" style="border-top-width:0; border-right-width:0; border-bottom-width:0; border-left-width:1px; border-color:rgb(181,20,16); border-top-style:none; border-right-style:none; border-bottom-style:none; border-left-style:solid;">
            <p>&nbsp;</p>
        </td>
        <td width="610" height="264">
            <table border="0" width="544" align="center">
                <tr>
                    <td width="80">
                        <p align="right"><font size="2" face="����" color="#B51410">Passwd 
                        </font></p>
                    </td>
                    <td width="454">
                        <p><input type=password name=passwd maxlength="15" size="15" class=box> <font size="2" face="����" color="#B51410">(������ ��ȣ�� ��ġ�ؾ� �մϴ�.)</p>
                    </td>
                </tr>
                <tr>
                    <td width="80">
                        <p align="right"><font size="2" face="����" color="#B51410">Subject 
                        </font></p>
                    </td>
                    <td width="454">
                        <p><input type=text name=subject maxlength="50" size="40" value="<? echo $row[subject] ?>" class=box></p>
                    </td>
                </tr>
                <tr>
                    <td width="80">
                        <p align="right"><font size="2" face="����" color="#B51410">Comment 
                        </font></p>
                    </td>
                    <td width="454">
                        <p><textarea rows="5" cols="60" name=comment class=box><? echo $row[comment] ?></textarea></p>
                    </td>
                </tr>
                <tr>
                    <td width="80">
                        <p align="right"><font size="2" face="����" color="#B51410">Picture 
                        </font></p>
                    </td>
                    <td width="454">
                        <p><input type=file name=upfile class=box maxlength="80" size="40"><br><font size="2" face="����" color="#B51410">
                      <?
                      if ($row[upfile_name])	{
                      $upfile_name = substr ($row[upfile_name],6,20);
                      echo " �̹� $upfile_name �� ��� �Ǿ����ϴ�.<input type=checkbox name=del_file>����";
                      }
                      ?>
                      	</p>
                    </td>
                </tr>
                <tr>
                    <td width="538" colspan="2">
                        <p align="center"><font color="#B51410" size="2" face="����">&nbsp;</font></p>
                    </td>
                </tr>
                <tr>
                    <td width="538" colspan="2">
                        <p align="center"><font color="#B51410" size="2" face="����">
                        <a href='javascript:WriteCheck();'>[ Save ]</a> 
                        <a href='javascript:document.tozzic.reset();'>[ Cancel ]</a>
                        <a href='javascript:history.go(-1);'>[ Back ]</a></font></p>
                    </td>
                </tr>
            </table>
        </td>
        <td width="30" height="264" background="img/line_4.gif">
            <p>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td width="22" style="border-top-width:0; border-right-width:0; border-bottom-width:1px; border-left-width:1px; border-bottom-color:rgb(181,20,16); border-left-color:rgb(181,20,16); border-top-style:none; border-right-style:none; border-bottom-style:solid; border-left-style:solid;">
            <p>&nbsp;</p>
        </td>
        <td width="610" style="border-bottom-width:1px; border-bottom-color:rgb(181,20,16); border-bottom-style:solid;">
            <p><font size="2" face="����" color="#B51410">Copyright �� <a href=http://tozigy.com target=_blank>Tozigy.com</a>. All rights reserved.</p>
        </td>
        <td width="30">
            <p><img src="img/line_5.gif" width="30" height="19" border="0"></p>
        </td>
    </tr>
</table></form>
<p>&nbsp;</p>
</body>
<script>
	document.tozzic.passwd.focus();
</script>

</html>

<?
	header('Location:/php/create_table.php');
?>

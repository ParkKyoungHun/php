<?
$title_name="게시판";
$limit = 12; // 한 페이지 당 보여줄 목록수
?>

<script language="javascript" src="../js/jquery-1.12.3.js"></script>
